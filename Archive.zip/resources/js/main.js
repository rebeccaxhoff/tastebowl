function toggle_style(){
    const colorstyle = document.getElementsByTagName("head")[0].getElementsByTagName("link")[0]
    const updatedTheme = colorstyle.getAttribute("href") === "/css/main.css" ? "/css/main.dark.css" : "/css/main.css" 
    colorstyle.href = updatedTheme;
    localStorage.setItem("color-mode", updatedTheme);
}

async function updateBanner(){
    URL = "/api/sale";
    const response = await fetch(URL);
    let json = await response.json();
    const banner = document.getElementById("main-banner")
    // console.log(banner)
    // console.log("json: ", json)

    if(banner){
        if(Object.keys(json).length == 0){
            banner.style.display = "none"
            console.log("remove")
            // remove banner
            return
        } else if(json.sale_text && json.time_end === null){  
            console.log("add")

            const messagediv = document.getElementById("message").innerText = json.sale_text
            banner.style.display = "block"
            // add banner
        }
    }
}

async function deleteBanner() {
    new_delete.addEventListener("click", async () => {
    URL = "/api/sale";
    const result = await fetch(URL, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            }
        });
    });
}

window.addEventListener("load", ()=>{
    setInterval(updateBanner, 1000)
    // handle submit
    const submit = document.getElementById("sale-submit");
    if(submit){
        submit.addEventListener("click", async () => {
            console.log("submitted");
            const message = {"message" : document.getElementById("sale").value};
            document.getElementById("sale").value = ""
            if(data.get()){

            }
            const result = await fetch(URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    },
                body: JSON.stringify(message),
            });
        console.log("status: ", result.status)
        if (!result.ok) {
            alert("oh no! Unable to make announcement.");
            return;
        } else{
            const form = document.getElementById("form-announcement")
            const text = document.createTextNode("Announcement Made!")
            if(form){
                form.appendChild(text)
                setTimeout(()=>{form.removeChild(text)}, 3500)
            }
            }
        })
    }

    // handle delete
    const deleteButton = document.getElementById("delete-sale");
        if(deleteButton){
            deleteButton.addEventListener("click", async ()=> {
                console.log("delete")

                const result = await fetch(URL, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                    },
                });
                if (!result.ok) {
                    alert("Oh no! Can't delete announcement");
                } else{
                    const form = document.getElementById("form-announcement")
                    const text = document.createTextNode("Announcement ended")
                    if(form){
                        form.appendChild(text)
                        setTimeout(()=>{form.removeChild(text)}, 3500)
                    }
                }
            })
        }

    const savedTheme = localStorage.getItem("color-mode");
    if(savedTheme){
        const colorstyle = document.getElementsByTagName("head")[0].getElementsByTagName("link")[0]
        colorstyle.href = savedTheme
    }
    document.getElementById("dark_mode_btn").addEventListener("click", toggle_style)
})