
window.addEventListener("load", calculatePrice)

// this function gets the select option and email when it is changes/filled out and calls updatePrice

function calculatePrice(){
    const select = document.getElementById("selection");
    select.addEventListener("change", updatePrice)

    const email = document.getElementById("email");
    email.addEventListener("change", updatePrice)
}



// this function calcultes the price and shows the price indicator
// If the user selects adoption, it is $10 fee for anything else it is only $3
// If the user has a school email, ie it has .edu at the end of the email address the student price is only 3, else it is 10
// the studentPrice and apptPrice is added to calculate the total.
// The highest amount is $20 and the lowest is $6
function updatePrice(){
    let studentPrice= 10
    let apptPrice= 10
    const selectInput = document.getElementById("selection");
    if(selectInput.value !== "Adoption"){
        apptPrice = 3
    }
    const emailInput = document.getElementById("email");
    const isStudent = emailInput.value.endsWith(".edu")
    if(isStudent){
        studentPrice = 3
    }

    const price = studentPrice + apptPrice
    console.log(price)
    const select = document.getElementById("selection");
    const apptType = select.value != "Select an option!" ? `your ${select.value}` : "this"
    const priceIndicator = document.getElementById("priceIndication");
    priceIndicator.innerHTML = `For ${apptType} appt ${isStudent ? 'and you are a student' : 'and you are not a student'}, the estimated price will be: $${price}`
}



