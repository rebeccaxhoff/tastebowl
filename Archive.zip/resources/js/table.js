
async function deleteRow(rowId){
    // console.log(rowId)
    let message = {"id": rowId}
    URL = "/api/contact";
    const result = await fetch(URL, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(message),
    })
    if(result.status == 200){
        let row = document.getElementById(rowId);
        row.parentNode.removeChild(row);
    } else {
        const deleteMessage = document.getElementById("popUpMessage");
        deleteMessage.removeAttribute("hidden")
        setInterval(()=>{deleteMessage.hasAttribute("hidden") ? deleteMessage.setAttribute("hidden", true) : undefined}, 4000);
    }
    console.log(result.status)
    console.log(JSON.stringify(message),)
    // console.log(result)
}  


setInterval(addTimeUntil, 1000);

// 2023-10-19T01:59

function addTimeUntil(){
    const currentDate = new Date().getTime();
    const rows = document.getElementById("contact-log").rows

    for(let i = 1; i< rows.length; i++){
        const date = rows[i].cells[2]; // get date row
        const dateValue = date.childNodes[0].nodeValue // get the date value
        console.log(date)
        const dateText = date.childNodes[1].childNodes[1] // get the p node

        if(dateValue === "No date"){ // check if date is null
            dateText.innerText = "N/a"
            continue;
        }

        const dateInMS = Date.parse(dateValue); 
        if(isNaN(dateInMS)) {
            dateText.innerText = "Invalid Date!" // check if date can be parsed
            continue
        }
        const timeUntilInMS = dateInMS - currentDate

        let timeUntil;
        if(timeUntilInMS < 0){ // check if time untill is negative
            timeUntil = "PAST"
            dateText.innerText = timeUntil
            continue;
        }

        // calculate time until
        const days = Math.floor(timeUntilInMS / (1000 *60*60*24))
        const hours = Math.floor((timeUntilInMS % (1000 *60*60*24)) / (1000 * 60 * 60)) // get remainder of days and convert to hours
        const minutes =  Math.floor((timeUntilInMS % (1000 *60*60)) / (1000 * 60)) // get remainder of hours and convert to minutes
        const seconds = Math.floor((timeUntilInMS % (1000 * 60)) / (1000)) // get remainder of minuites and conver to seconds

        timeUntil = `${days} days, ${hours} hour(s), ${minutes} minute(s), ${seconds} second(s) until the appointment`
        dateText.innerText = timeUntil
    }

}